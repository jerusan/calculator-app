To run this locally, 

run front end
 serve -s build 
   default port num: 5000
   use -l <port_num> to choose different port number

run backend locally
  ./server.exe 
   num of recent calculations saved: 10
   optional flag -list-size=<num> to change the size  

type localhost:<port_num> to access this application